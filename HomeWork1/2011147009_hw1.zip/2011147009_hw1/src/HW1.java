// OOP Homework1 
// Name: Jeong Jae Hwan
// Student ID : 2011147009

//package information 
import java.util.*; // for using Scanner class 
import java.lang.Math; // import math package 


public class HW1{
	public static void main(String[] args){
		
		final int LIMIT=30; // define constant variable named LIMIT , and assign 30 as value.
		Scanner s = new Scanner(System.in); // make an Scanner instance s for using keyboard input function
		//initializing block : p1_score : player 1's score, p2_score : player 2's score.
		//turn starts with player 1 so assign initial value as 1, output format descriptionr as follows.
		int p1_score=0;
		int p2_score=0;
		int turn =1; 
		System.out.println("GAME START (Goal 30 points)");
		
Label1: while(true){ // block which runs in each player's turn 
			
			System.out.println("-----------------------------------------------");
			int tmp = (int)(Math.random()*6)+1; // create a random number (1 ~ 6)
			//int tmp = s.nextInt(); -> used for debugging
			System.out.println("Player "+turn+" (" +((turn==1)?p1_score:p2_score)+") rolls ... "+tmp);
			
			//initial step, player rolls a dice 
			if(tmp==1){ // case 1 : turn changes 
				System.out.println("Oh.. poor..");
				turn = (turn==1) ? 2 : 1;  
				System.out.println("Turn to player "+ turn);
			}
			else{ // case 2~6 :
					int temp_score = (turn==1)? p1_score:p2_score; // store target player's origin_score for checking LIMIT and    
					int temp_sum=tmp; // stores initial randoom number 
					temp_score+=tmp; // for hold or check LIMIT add first random number to temp_score
					if(temp_score>=LIMIT){ // if temp_sum>=30(with first step) , then break 
						if(turn==1)
							p1_score=temp_score;
						else
							p2_score=temp_score;
						break;
					}
					while( true ){ // block which runs in repeating 'roll' and 'hold' 
						System.out.print("Player " + turn+ " ("+((turn==1)?p1_score:p2_score)+") input (r)oll or (h)old: ");
						String str=s.nextLine(); //input A string 
						
						if(str.equals("h") ){ //hold step
							//assign temp value to each player's score 
							if(turn==1)
								p1_score=temp_score;
							else
								p2_score=temp_score;
							//player turn changes output format 
							System.out.println("Player "+turn+ " ("+((turn==1)?p1_score:p2_score)+") gets "+temp_sum);
							
							turn= (turn==1) ? 2:1; // change turn and break
							System.out.println("Turn to player "+ turn);
							break;
						}
						else if(str.equals("r")){ // roll step  
							System.out.println("Roll again");
							//tmp = s.nextInt(); -> used for debugging
							tmp = (int)(Math.random()*6)+1; // create a new random number for roll step 
							System.out.println("Player "+turn+ " ("+((turn==1)?p1_score:p2_score)+") rolls ... "+tmp);
							if(tmp==1){ // within roll step, if new random number becomes 1, then no changes with each player's score  
								System.out.println("Oh.. poor..");
								turn=((turn==1)?2:1); // change turns 
								System.out.println("Turn to player "+ turn);
								break;
							}
							//with each step, case 2~6 add tmp value 
							temp_score+=tmp;
							temp_sum+=tmp;
							
							if(temp_score>=LIMIT){ //repeating roll step, and if accumulated score is above 30, then break whole process 
								if(turn==1)
									p1_score=temp_score;
								else
									p2_score=temp_score;
								break Label1; // escape whole loop (escape loop Label1) 
							}	
							// if not score doesn't exceed LIMIT, then repeat the 'h' , 'r' step with the same player 
						}
					}				
			}
		}
		// exit output format : output winner's score and player's name with "Game End" sentence.
		System.out.println("Player "+ turn+ " ("+((turn==1)? p1_score:p2_score)+") wins ... Automatic ending..." );
		System.out.println("Game Ends..");
	}
}
